import React, { useEffect, useState } from 'react';
import './StockValueComplaints.css';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';

const StockValueComplaints = () => {
  const [complaints, setComplaints] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedStatus, setSelectedStatus] = useState('');
  const [recordsPerPage, setRecordsPerPage] = useState(10);
  const [currentPage, setCurrentPage] = useState(1);
  const [activeComplaint, setActiveComplaint] = useState(null);
  const [resolutionMessage, setResolutionMessage] = useState('');
  const [proofFile, setProofFile] = useState(null);

  useEffect(() => {
    const fetchComplaints = async () => {
      try {
        const fakeData = [
          {
            id: 'CMP101',
            item: 'Copper Wire',
            subject: 'Damaged item',
            description: 'Transformer delivered was damaged.',
            reportedBy: 'Store Incharge',
            userType: 'Registered Center',
            centerEmail: 'center101@nbpdcl.com',
            type: 'Damaged Equipment',
            status: 'Pending',
            date: '2025-06-22',
          },
          {
            id: 'CMP102',
            item: 'Fuse Box',
            subject: 'Broken packaging',
            description: 'Fuse box was broken when received.',
            reportedBy: 'John Doe',
            userType: 'Public User',
            email: 'johndoe@gmail.com',
            type: 'Pole Issue',
            status: 'Pending',
            date: '2025-06-20',
          },
        ];
        await new Promise((res) => setTimeout(res, 800));
        setComplaints(fakeData);
        setLoading(false);
      } catch (err) {
        console.error('Failed to load complaints', err);
        setLoading(false);
      }
    };

    fetchComplaints();
  }, []);

  const filteredComplaints = complaints
    .filter((c) =>
      c.item.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.subject.toLowerCase().includes(searchTerm.toLowerCase())
    )
    .filter((c) => (selectedStatus ? c.status === selectedStatus : true));

  const indexOfLast = currentPage * recordsPerPage;
  const indexOfFirst = indexOfLast - recordsPerPage;
  const currentRecords = filteredComplaints.slice(indexOfFirst, indexOfLast);
  const totalPages = Math.ceil(filteredComplaints.length / recordsPerPage);

  const handleDownloadPDF = () => {
    const doc = new jsPDF();
    doc.text('Stock Value Complaints', 14, 15);
    autoTable(doc, {
      head: [['ID', 'Item', 'User Type', 'Reported By', 'Status', 'Date']],
      body: filteredComplaints.map((c) => [
        c.id,
        c.item,
        c.userType,
        c.reportedBy,
        c.status,
        c.date,
      ]),
      startY: 20,
    });
    doc.save('stock-value-complaints.pdf');
  };

  const handleResolve = () => {
    const updated = complaints.map((comp) =>
      comp.id === activeComplaint.id
        ? {
            ...comp,
            status: 'Resolved',
            resolution: resolutionMessage,
            proof: proofFile?.name || 'No file attached',
          }
        : comp
    );
    setComplaints(updated);
    setActiveComplaint(null);
    setResolutionMessage('');
    setProofFile(null);
  };

  return (
    <div className="svc-container">
      <h2 className="svc-heading">📄 Stock Value Complaints</h2>

      <div className="svc-toolbar">
        <input
          type="text"
          className="svc-search"
          placeholder="Search complaints..."
          value={searchTerm}
          onChange={(e) => {
            setSearchTerm(e.target.value);
            setCurrentPage(1);
          }}
        />

        <select
          className="svc-select"
          value={selectedStatus}
          onChange={(e) => {
            setSelectedStatus(e.target.value);
            setCurrentPage(1);
          }}
        >
          <option value="">All Status</option>
          <option value="Pending">Pending</option>
          <option value="Resolved">Resolved</option>
        </select>

        <select
          className="svc-select"
          value={recordsPerPage}
          onChange={(e) => {
            setRecordsPerPage(Number(e.target.value));
            setCurrentPage(1);
          }}
        >
          {[5, 10, 20].map((num) => (
            <option key={num} value={num}>
              {num} per page
            </option>
          ))}
        </select>

        <button className="download-btn" onClick={handleDownloadPDF}>
          📄 Download PDF
        </button>
      </div>

      {loading ? (
        <p className="svc-loading">Loading complaints...</p>
      ) : currentRecords.length === 0 ? (
        <p className="svc-empty">No complaints found related to stock value.</p>
      ) : (
        <table className="svc-table">
          <thead>
            <tr>
              <th>Complaint ID</th>
              <th>Item</th>
              <th>Subject</th>
              <th>Description</th>
              <th>Reported By</th>
              <th>Status</th>
              <th>Date</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {currentRecords.map((c, index) => (
              <tr key={`${c.id}-${index}`}>
                <td>{c.id}</td>
                <td>{c.item}</td>
                <td>{c.subject}</td>
                <td>{c.description}</td>
                <td>{c.reportedBy}</td>
                <td>
                  <span className={`status ${c.status.toLowerCase()}`}>{c.status}</span>
                </td>
                <td>{c.date}</td>
                <td>
                  {c.status === 'Pending' && (
                    <button onClick={() => setActiveComplaint(c)}>🛠 Resolve</button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}

      {filteredComplaints.length > recordsPerPage && (
        <div className="pagination-controls">
          <button
            onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
            disabled={currentPage === 1}
          >
            ⬅️ Previous
          </button>
          <span>
            Page {currentPage} of {totalPages}
          </span>
          <button
            onClick={() => setCurrentPage((prev) => Math.min(prev + 1, totalPages))}
            disabled={currentPage === totalPages}
          >
            Next ➡️
          </button>
        </div>
      )}

      {activeComplaint && (
        <div className="reply-modal">
          <div className="reply-box">
            <h3>Resolve Complaint: {activeComplaint.id}</h3>
            <p><strong>User Type:</strong> {activeComplaint.userType}</p>

            {activeComplaint.userType === 'Registered Center' ? (
              <>
                <p><strong>Center Email:</strong> {activeComplaint.centerEmail}</p>
                <p><strong>Reported By:</strong> {activeComplaint.reportedBy}</p>
              </>
            ) : (
              <>
                <p><strong>Name:</strong> {activeComplaint.reportedBy}</p>
                <p><strong>Email:</strong> {activeComplaint.email}</p>
              </>
            )}

            <p><strong>Item:</strong> {activeComplaint.item}</p>
            <p><strong>Complaint Type:</strong> {activeComplaint.type}</p> {/* 👈 Added here */}
            <p><strong>Subject:</strong> {activeComplaint.subject}</p>
            <p><strong>Description:</strong> {activeComplaint.description}</p>
            <p><strong>Date:</strong> {activeComplaint.date}</p>

            <label>Resolution Message:</label>
            <textarea
              rows={4}
              value={resolutionMessage}
              onChange={(e) => setResolutionMessage(e.target.value)}
              placeholder="Type resolution details..."
            />

            <label>Attach Proof (optional):</label>
            <input
              type="file"
              onChange={(e) => setProofFile(e.target.files[0])}
            />

            <div className="reply-buttons">
              <button onClick={handleResolve}>✅ Submit</button>
              <button
                onClick={() => {
                  setActiveComplaint(null);
                  setResolutionMessage('');
                  setProofFile(null);
                }}
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default StockValueComplaints;
